package com.example.farmerscart.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.farmerscart.R;

public class ProfileEditUserActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_edit_user);
    }
}