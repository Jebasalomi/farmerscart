package com.example.farmerscart;

import java.util.Locale;

public class Constants {

    public static final String[] productCategories = {
            "Vegetables",
            "Fruits",
            "Fertilizer",
            "Seeds",
            "Rice",
            "Pulses"

    };

    public static final String[] productCategories1 = {
            "All",
            "Vegetables",
            "Fruits",
            "Fertilizer",
            "Seeds",
            "Rice",
            "Pulses"

    };

}
